export class TypeMission {
    
    _id!: string;
     createdBy!: string;
     typeMission! : string;
     description!: string;
     statut!: boolean;
 }
