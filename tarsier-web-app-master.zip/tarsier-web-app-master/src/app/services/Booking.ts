export class Booking {

    _id!: string;
     createdBy!: string;
     userId!: string;
     num_reservation! : string;
     typeMissionId!: string;
     perimeterId!: string;
     equipId!: string;
     statut!: string;
     start!: Date;
     end!: Date;
 }