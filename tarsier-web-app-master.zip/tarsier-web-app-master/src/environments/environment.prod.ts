export const environment = {
  production: true,
  // serverUrl: 'https://us-central1-tarsio-demo.cloudfunctions.net/app'
  serverUrl: 'https://www.smartlogger.ovh/torsier'
};
