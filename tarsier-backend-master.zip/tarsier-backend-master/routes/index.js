module.exports = {
    authRoutes: require('./auth.routes'),
    bookingRoutes: require('./booking.routes'),
    leakRoutes: require('./leak.routes'),
    perimeterRoutes: require('./perimeter.routes'),
    equipRoutes: require('./equip.routes'),
    typeEquipRoutes: require('./typeEquip.routes'),
    typesMissionRoutes: require('./typesMission.routes'),
    freqControleRoutes: require('./freqControle.routes'),

};