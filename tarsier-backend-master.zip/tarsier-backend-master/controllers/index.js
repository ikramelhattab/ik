
module.exports = {
    authController: require('./auth.controller.js'),
    bookingController: require('./booking.controller'),
    leakController: require('./leak.controller'),
    perimeterController: require('./perimeter.controller'),
    equipController: require('./equip.controller'),
    typeEquipController: require('./typeEquip.controller'),
    typesMissionController: require('./typesMission.controller'),
    freqController: require('./freq.controller')
};