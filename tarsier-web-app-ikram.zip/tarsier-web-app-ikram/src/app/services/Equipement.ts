export class Equipement {
    _id!: string;
     createdBy!: string;
     code! : string;
     description!: string;
     typeEquipId!: string;
     statut!: Boolean;
     facteur!: number;
     photoUrl!: string;
     
 }