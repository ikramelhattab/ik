export class FreqControle {
    _id!: string;
     createdBy!: string;
     _0_100euro! : number;
     _100_500euro!: number;
     _500_1500euro!: number;
     _1500euro!: number;
     horizon!: number;
 }