export class Mission {

    _id!: string;
    createdBy!: string;
    date!: Date;
    perimetre! : string;
    responsable!: string;
    createdOn!: Date;

}