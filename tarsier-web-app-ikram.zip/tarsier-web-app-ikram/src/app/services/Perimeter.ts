export class Perimeter {
   _id!: string;
    createdBy!: string;
    code! : string;
    description!: string;
    createdOn!: Date;
    statut!: string;
    photoUrl!: string;
}