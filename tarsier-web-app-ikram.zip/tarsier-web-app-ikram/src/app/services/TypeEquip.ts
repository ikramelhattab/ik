export class TypeEquip {
    
    _id!: string;
     createdBy!: string;
     typeEquip! : string;
     description!: string;
     statut!: boolean;
 }
